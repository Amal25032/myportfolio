// Select the theme toggle button
const themeToggle = document.getElementById('theme-toggle');

// Load saved theme from localStorage (if any)
const savedTheme = localStorage.getItem('theme');
if (savedTheme) {
    document.body.setAttribute('data-theme', savedTheme);
    themeToggle.textContent = savedTheme === 'dark' ? '☀️' : '🌙';
} else {
    // Default theme
    document.body.setAttribute('data-theme', 'light');
}

// Add click event listener to toggle theme
themeToggle.addEventListener('click', () => {
    // Get the current theme
    const currentTheme = document.body.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

    // Set the new theme
    document.body.setAttribute('data-theme', newTheme);

    // Save the new theme to localStorage
    localStorage.setItem('theme', newTheme);

    // Update the button text/icon
    themeToggle.textContent = newTheme === 'dark' ? '☀️' : '🌙';
});
